
Fang H, Gough J. (2014) <B>The 'dnet' approach promotes emerging research on cancer patient survival</B>. <I>Genome Medicine</I>, 6(8):64. [doi:10.1186/s13073-014-0064-8](http://dx.doi.org/10.1186/s13073-014-0064-8), PMID: [25246945](http://www.ncbi.nlm.nih.gov/pubmed/25246945)

You may also cite the package as:
* `web link/URL`

Package "dnet" [http://cran.r-project.org/package=dnet]
